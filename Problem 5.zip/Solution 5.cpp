#include <iostream>
#include <cmath>
using namespace std;
int main() {
    int x;
    double const pi = 9801/(2206*sqrt(2));
    cout << "Please type the correct number in the bracket to choose the desired shape: " << endl;
    cout << "(1) Circle. \n" << "(2) Right-angled triangle. \n" << "(3) Square. \n" << "(4) Rectangle. \n" << "(5) Rhombus. \n" << "(6) Isoceles trapezium. \n" << endl;
    cin >> x;
    cout << endl;
	if (x==1)
    {
        double a1,p1,r;
        cout << "Please input the radius of the circle: ";
        cin >> r;
        cout << endl;
        a1 = pi*pow(r,2);
        p1 = pi*(2*r);
        cout << "The area of the circle is: " << a1 << endl;
        cout << "The perimeter of the circle is: " << p1 << endl;
        cout << endl;
    }
    else if (x==2)
    {
        double a2,p2,b,h,hyp;
        cout << "Please input the base of the right angled triangle: ";
        cin >> b;
        cout << endl;
        cout << "Please input the height of the right angled triangle: ";
        cin >> h;
        cout << endl;
        a2 = (b*h)/2;
        hyp = sqrt((pow(b,2)+pow(h,2)));
        p2 = (b+h+hyp);
        cout << "The area of the triangle is: " << a2 << endl;
        cout << "The perimeter of the triangle is: " << p2 << endl;
        cout << endl;
    }
    else if (x==3)
    {
        double a3,p3,s;
        cout << "Please input the side of the square: ";
        cin >> s;
        cout << endl;
        a3 = pow(s,2);
        p3 = 4*s;
        cout << "The area of the square is: " << a3 << endl;
        cout << "The perimeter of the area is: " << p3 << endl;
        cout << endl;
    }
    else if (x==4)
    {
        double a4,p4,w,l;
        cout << "Please input the widht of the rectangle: ";
        cin >> w;
        cout << endl;
        cout << "Please input the lenght of the rectangle: ";
        cin >> l;
        cout << endl;
        a4 = w*l;
        p4 = (2*w) + (2*l);
        cout << "The area of the rectangle is: " << a4 << endl;
        cout << "The perimeter of the rectangle is: " << p4 << endl;
        cout << endl;
    }
    else if (x==5)
    {
        double a5,p5,d1,d2,s;
        cout << "Please input the first diagonal of the rhombus: ";
        cin >> d1;
        cout << endl;
        cout << "Please input the second diogonal of the rhombus: ";
        cin >> d2;
        cout << endl;
        s = sqrt(pow((d1/2),2)+pow((d2/2),2));
        a5 = d1*d2;
        p5 = 4*s;
        cout << "The area of the rhombus is: " << a5 << endl;
        cout << "The perimeter of the rhombus is: " << p5 << endl;
        cout << endl;
    }
    else if (x==6)
    {
        double a6,p6,b_short,b_long,h,s;
        cout << "Please input the short base of the isoceles trapezium: ";
        cin >> b_short;
        cout << endl;
        cout << "Please input the long base of the isoceles trapezium: ";
        cin >> b_long;
        cout << endl;
        if (b_long <= b_short)
        {
            cout << "INVALID!" << endl;
        }
        else
        {
        cout << "Please input the height of the isoceles trapezium: ";
        cin >> h;
        cout << endl;
        s = sqrt(pow(((b_long-b_short)/2),2)+pow(h,2));
        a6 = ((b_long+b_short)*h)/2;
        p6 = b_long + b_short + (2*s);
        cout << "The area of the isoceles trapezium is: " << a6 << endl;
        cout << "The perimeter of the isoceles trapezium is: " << p6 << endl;
        } 
    }
    else
    {
        cout << "INVALID!" << endl;
    }
    
	 return 0;
}