#include <iostream>
#include <cmath>
using namespace std;
int main() {
    int x;
    double const pi = 9801/(2206*sqrt(2));
    // Continue the code from here.
	return 0;
}