#include <iostream>
using namespace std;
int main () {
    int x;
    cout << "Please input the lenght of the side intended: " << endl;
    cin >> x;
    for (int i=1;i<=x;++i){
        for(int j=1;j<=x;++j){
            if (i==1 || i==x){
                cout << "*";
            }

            else if (i==2 || i==(x-1)){
                if (j==1 || j==x){
                    cout << "*";
                }
                else {
                    cout << " ";
                }
            }

            else if (i==3 || i==(x-2)){
                if (j==1 || j==x){
                    cout << "*";
                }
                else if (j==2 || j==(x-1)){
                    cout << " ";
                }
                else {
                    cout << "*";
                }
            }

            else if (i>3 || i<(x-2)) {
                if (j==1 || j==x){
                    cout << "*";
                }
                else if (j==2 || j==(x-1)){
                    cout << " ";
                }
                else if (j==3 || j==(x-2)){
                    cout << "*";
                }
                else {
                    cout << " ";
                }
            }

            else {}

        }
        cout << endl;
    }
    return 0;
}
