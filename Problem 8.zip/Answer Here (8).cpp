#include <iostream>
using namespace std;
int main () {
    int x;
    cout << "Please input the lenght of the side intended: " << endl;
    cin >> x;
    // Continue the code from here.
    return 0;
}
