#include <iostream>
#include <cmath>
using namespace std;
int main() {
    // Continue the code from here.
	return 0;
}
