#include <iostream>
#include <cmath>
using namespace std;
int main() {
    int x;
    cout << "Please input an interger: ";
    cin >> x;
    
    cout << "Square sequence: ";
    if (x<=0){
    	cout << "INVALID!";
		}
	else{
		for (int i=1; i<=x; ++i){
        cout << pow(i,2) << " ";
    }
	}
	
    cout << endl;
    cout << "Prime sequence: ";
    if (x<=0){
    	cout << "INVALID!";
	}
	else if (x==1){
		cout << "2";
	}
	else if (x==2){
		cout << "2 3";
	}
	else if (x==3){
		cout << "2 3 5";
	}
    else
    cout << "2 3 5 ";
    for(int i=1; i<=(x-3); ++i){
    	int y;
    	y=(6*i)+1;
    	cout << y << " ";
	}
	
	cout << endl;
	cout << "Factorial sequence: ";
	if (x<=0){
		cout << "INVALID!";
	}
	else {
			int a=1;
			for (int i=1; i<=x; ++i){
			        a*=i;
			        cout << a << " ";  
	}
}

	cout << endl;
	cout << "Fibonacci sequence: ";
	if (x<=0){
		cout << "INVALID!";
	}
	else {
		int I=0,II=1,NT=0;
	for (int i=1; i<=x; ++i){
		if (i==1){
		}
		else{
		}
		if (i==2){
			cout << II << " ";
		}
		else{
		}
		NT=I+II;
		I=II;
		II=NT;
		cout << NT << " ";
	}
	}

	return 0;
}
