#include <iostream>
using namespace std;
int main () {
    a = 5;
    b = 2.5;
    c = 'c';
    d = "Hello world!";
    e = true;

    cout << a << endl;
    cout << b << endl;
    cout << c << endl;
    cout << d << endl;
    cout << e << endl;

    return 0;
}