// .cpp Practice Problem I
//
// Instructions:
// Give the variables the appropriate variable type, so that the code may work properly.
//
// Conditions:
// Do not remove anything from the "Answer 1" file.