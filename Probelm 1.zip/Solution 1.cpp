
#include <iostream>
using namespace std;
int main () {
    int a = 5; 
    double b = 2.5;
    char c = 'c';
    string d = "Hello world!";
    bool e = true;
    cout << a << endl;
    cout << b << endl;
    cout << c << endl;
    cout << d << endl;
    cout << e << endl;

    return 0;
}

// Notes:
// Add the appropriate variable type to each variable.