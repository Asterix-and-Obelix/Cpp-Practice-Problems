#include <iostream>
using namespace std;
int main () {
    int a,b,c;
    cout << "Please input an interger for a: ";
    cin >> a; cout << endl;
    cout << "Please input an interger for b: ";
    cin >> b; cout << endl;
    //
    //
    //
    cout << "Now, the value of a is " << a << " and the value of b is " << b << ".";
    return 0;
}