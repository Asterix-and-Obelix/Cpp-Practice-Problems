#include <iostream>
using namespace std;
int main() {
    double a,b,c,d,e,s;
    cout << "Please input the scores : ";
    cout << endl;
    cout << "Science : ";
    cin >> a; 
    cout << endl;
    cout << "Mathematics : ";
    cin >> b; 
    cout << endl;
    cout << "Chemistry : ";
    cin  >> c; 
    cout << endl;
    cout << "Biology : ";
    cin >> d; 
    cout << endl;
    cout << "Social Studies : ";
    cin >> e; 
    cout << endl;

    s = (a+b+c+d+e)/5;
    cout << "Final grade by score is : " << s << endl;
    if (85<=s && s<=100)
    {
        cout << "Final grade by letter is : " << "A" << endl;
    }
    else if (70<=s && s<=84)
    {
        cout << "Final grade by letter is : " << "B" << endl;
    }
    else if (60<=s && s<=69)
    {
        cout << "Final grade by letter is : " << "C" << endl;
    }
    else if (50<=s && s<=59)
    {
        cout << "Final grade by letter is : " << "D" << endl;
    }
    else if (0<=s && s<=49)
    {
        cout << "Final grade by letter is : " << "E" << endl;
    }
    else
    {
        cout << "INVALID!" << endl;
    }
    
    return 0;
}