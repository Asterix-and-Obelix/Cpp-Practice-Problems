#include <iostream>
using namespace std;
int main () {
    int r;
    cout << "How many round(s) of game do you want to play? "; cin >> r;

    string a, b;
    int c = 0, d = 0;
    for (int i = 0; i < r; i++) {
        
        cout << "---" << endl; 
        cout << "Round " << (i+1) << endl;
        cout << "Choose Rock/Paper/Scissor for player 1: "; cin >> a;
        cout << "Choose Rock/Paper/Scissor for player 2: "; cin >> b;

        if (a == b) {
            cout << "it's a draw!" << endl;
        }

        else if (a == "Rock" && b == "Paper") {
            cout << "Player 2 wins!" << endl; d++;
        }

        else if (a == "Rock" && b == "Scissor") {
            cout << "Player 1 wins!" << endl; c++;
        }

        else if (a == "Paper" && b == "Rock") {
            cout << "Player 1 wins!" << endl; c++;
        }

        else if (a == "paper" && b == "Scissor") {
            cout << "Player 2 wins!" << endl; d++;
        }

        else if (a == "Scissor" && b == "Paper") {
            cout << "Player 1 wins!" << endl; c++;
        }

        else if (a== "Scissor" && b == "Rock") {
            cout << "Player 2 wins!" << endl; d++;
        }

        if (i == (r-1)) {

            if (c > d) {
                cout << "---" << endl << "The final winner is player 1!";
            }

            else if (c < d) {
                cout << "---" << endl << "The final winner is Player 2!";
            }

        }

    }
    
    return 0;
}