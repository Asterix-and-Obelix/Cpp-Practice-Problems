#include <iostream>
using namespace std;
int main () {
    double const pi = 9801/(2206*sqrt(2));
    double const e = 2721/1001;
    cout << "pi plus e is: " << // << endl;
    cout << endl;
    cout << "pi minus e is: " << // << endl;
    cout << endl;
    cout << "pi times e is: " << // << endl;
    cout << endl;
    cout  << "pi divided by e is: " << // << endl;
    cout << endl;
    return 0;
}

