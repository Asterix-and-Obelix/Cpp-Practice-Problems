#include <iostream>
using namespace std;
int main () {
    double const pi = 9801/(2206*sqrt(2));
    double const e = 2721/1001;
    cout << "pi plus e is: " << pi + e << endl;
    cout << "Your answer is correct if a plus b displays 5.14159";
    cout << endl << endl;
    cout << "pi minus e is: " << pi - e << endl;
    cout << "Your answer is correct if pi minus e displays 1.14159";
    cout << endl << endl;
    cout << "pi times e is: " << pi * e << endl;
    cout << "Your answer is correct if pi times e displays 6.28319";
    cout << endl << endl;
    cout  << "pi divided by e is: " << pi / e << endl;
    cout << "Your answer is correct if pi divided by e displays 1.5708";
    cout << endl;
    return 0;
}